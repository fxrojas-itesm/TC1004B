
@echo off
setlocal enabledelayedexpansion

:: Check for admin rights
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: Get the folder where the .bat file is located
set "DRIVER_FOLDER=%~dp0"

:: Loop through all .inf files in the folder
for %%f in ("%DRIVER_FOLDER%\*.inf") do (
	echo ----------------------.
    echo Installing driver: %%~nxf
    pnputil /add-driver "%%f" /install

    if !ERRORLEVEL! EQU 0 (
        echo Successfully installed: %%~nxf
    ) else (
        echo Failed to install: %%~nxf (Error code !ERRORLEVEL!)
    )
    echo.
)

pause
endlocal
